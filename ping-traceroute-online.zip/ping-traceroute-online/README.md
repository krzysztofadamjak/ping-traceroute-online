# Ping / Traceroute Online

Aplikacja internetowa umożliwiająca wykonanie poleceń `ping` oraz `traceroute` na wskazany host.

## ⚙️ Instalacja i uruchomienie

```bash
git clone https://github.com/TWOJ_UZYTKOWNIK/ping-traceroute-online.git
cd ping-traceroute-online
npm install
npm start
```

Następnie otwórz w przeglądarce: [http://localhost:3000](http://localhost:3000)

## 🛡️ Bezpieczeństwo

Nie wystawiaj tej aplikacji publicznie bez odpowiednich zabezpieczeń – wykonuje ona polecenia systemowe!